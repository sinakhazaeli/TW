# Traffic Whisperer — Godot Rebuild Milestone 1

This is a clean Godot 4 project, not a port of the HTML prototype.

## Current vertical slice
- Karaköy intersection world scene
- Four physical approach queues with vehicle-specific spacing
- Drag gesture to assign left/right/straight route to queue leader
- Traffic signal gating (N/S vs E/W)
- Intersection occupancy protection
- Car, taxi, motorcycle, bus and ambulance types
- Ambulance deadline and hospital route
- Three escalating waves: Morning Flow, Ferry Rush, Peak Hour
- Gridlock pressure, combo, scoring and 1–3 star finish
- Touch + mouse input
- Godot Web export preset configured

## Project structure
- `scenes/` — gameplay scenes
- `scripts/traffic/` — traffic simulation and vehicles
- `scripts/world/` — road graph and route geometry
- `levels/` — level configuration data
- `assets/` — separated asset pipeline folders
- `audio/` — audio asset folder

## Open/run
Open `project.godot` in Godot 4.x and press Run Project.

## Web export
Install matching Godot export templates, then export the preset `Web` to `web/index.html`.
