extends Node2D

var road := TWRoadNetwork.new()
var traffic := TWTrafficManager.new()
var selected: TWVehicle = null
var state: String = "menu"
var feedback_time: float = 0.0
var feedback_text: String = ""

@onready var hud: CanvasLayer = $HUD
@onready var menu: CanvasLayer = $Menu
@onready var result: CanvasLayer = $Result
@onready var live_status: Label = $HUD/LiveStatus
@onready var action_text: Label = $HUD/ActionPanel/ActionText
@onready var route_panel: HBoxContainer = $HUD/ActionPanel/RoutePanel
@onready var left_btn: Button = $HUD/ActionPanel/RoutePanel/Left
@onready var straight_btn: Button = $HUD/ActionPanel/RoutePanel/Straight
@onready var right_btn: Button = $HUD/ActionPanel/RoutePanel/Right
@onready var signal_hotspot: Button = $HUD/SignalHotspot
@onready var roadworks_hotspot: Button = $HUD/RoadworksHotspot
@onready var hint_hotspot: Button = $HUD/HintHotspot
@onready var result_title: Label = $Result/Card/Title
@onready var result_sub: Label = $Result/Card/Sub

func _ready() -> void:
    add_child(road)
    add_child(traffic)
    traffic.setup(self, road)
    traffic.score_changed.connect(_on_score)
    traffic.ambulance_changed.connect(_on_ambulance)
    traffic.level_complete.connect(_on_complete)
    traffic.level_failed.connect(_on_fail)
    traffic.wave_changed.connect(_on_wave)

    $Menu/Card/Play.pressed.connect(start_game)
    $Result/Card/Again.pressed.connect(start_game)
    signal_hotspot.pressed.connect(_on_signal_pressed)
    roadworks_hotspot.pressed.connect(_on_roadworks_pressed)
    hint_hotspot.pressed.connect(_on_hint_pressed)
    left_btn.pressed.connect(func() -> void: _dispatch_selected("left"))
    straight_btn.pressed.connect(func() -> void: _dispatch_selected("straight"))
    right_btn.pressed.connect(func() -> void: _dispatch_selected("right"))

    route_panel.visible = false
    queue_redraw()

func start_game() -> void:
    state = "playing"
    selected = null
    menu.visible = false
    result.visible = false
    hud.visible = true
    route_panel.visible = false
    traffic.start()
    _feedback("TAP A GLOWING QUEUE LEADER", 3.0)
    queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
    if state != "playing":
        return

    if event is InputEventScreenTouch and event.pressed:
        _select_at(event.position)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        _select_at(event.position)

func _select_at(pos: Vector2) -> void:
    # Route/control buttons consume their own input; this handles the playfield.
    var candidate: TWVehicle = null
    var best_distance: float = 999999.0

    for entry in ["north", "south", "west", "east"]:
        var v: TWVehicle = traffic.head(entry)
        if is_instance_valid(v):
            var d: float = v.global_position.distance_to(pos)
            if d < 115.0 and d < best_distance:
                candidate = v
                best_distance = d

    if candidate == null:
        _feedback("TAP THE CYAN-RINGED FRONT CAR", 1.5)
        return

    _set_selected(candidate)

func _set_selected(v: TWVehicle) -> void:
    if is_instance_valid(selected):
        selected.selected = false
        selected.queue_redraw()

    selected = v
    selected.selected = true
    selected.queue_redraw()
    route_panel.visible = true

    if selected.emergency:
        action_text.text = "AMBULANCE SELECTED · CHOOSE ITS EXIT"
    else:
        action_text.text = "CHOOSE ROUTE · LEFT / STRAIGHT / RIGHT"

    queue_redraw()

func _dispatch_selected(turn: String) -> void:
    if state != "playing" or not is_instance_valid(selected):
        _feedback("SELECT A GLOWING QUEUE LEADER FIRST", 1.5)
        return

    var v: TWVehicle = selected
    var result_data: Dictionary = traffic.dispatch(v, turn)
    _feedback(String(result_data.get("msg", "READY")), 1.3)

    if bool(result_data.get("ok", false)):
        v.selected = false
        v.queue_redraw()
        selected = null
        route_panel.visible = false

    queue_redraw()

func _on_signal_pressed() -> void:
    if state != "playing":
        return
    var result_data: Dictionary = traffic.toggle_signal()
    _feedback(String(result_data.get("msg", "SIGNAL SWITCHED")), 1.4)

func _on_roadworks_pressed() -> void:
    if state != "playing":
        return
    var result_data: Dictionary = traffic.activate_roadworks()
    _feedback(String(result_data.get("msg", "ROADWORKS")), 1.8)

func _on_hint_pressed() -> void:
    if state != "playing":
        return
    var v: TWVehicle = traffic.recommended_head()
    if is_instance_valid(v):
        _set_selected(v)
        _feedback("HINT · THIS QUEUE CAN MOVE NOW", 2.0)
    else:
        _feedback("HINT · SWITCH THE LIGHT FIRST", 1.6)

func _process(delta: float) -> void:
    if feedback_time > 0.0:
        feedback_time -= delta
        if feedback_time <= 0.0 and state == "playing":
            if is_instance_valid(selected):
                action_text.text = "CHOOSE ROUTE · LEFT / STRAIGHT / RIGHT"
            else:
                action_text.text = "TAP A CYAN-RINGED QUEUE LEADER"
    queue_redraw()

func _feedback(text: String, duration: float) -> void:
    feedback_text = text
    feedback_time = duration
    action_text.text = text

func _on_score(score: int, cleared: int, jam: float, combo: int) -> void:
    live_status.text = "LIVE  %02d/18   ·   JAM %02d%%   ·   x%d   ·   %05d" % [cleared, int(jam), combo, score]

func _on_ambulance(seconds: float) -> void:
    if seconds >= 0.0:
        if not is_instance_valid(selected) or not selected.emergency:
            action_text.text = "🚑 AMBULANCE %.0fs · CLEAR WEST QUEUE" % seconds

func _on_wave(name: String) -> void:
    _feedback(name, 2.0)

func _on_complete(score: int, stars: int) -> void:
    state = "result"
    hud.visible = false
    result.visible = true
    result_title.text = "KARAKÖY CLEARED"
    result_sub.text = "Score %d   ·   %s" % [score, "★".repeat(stars) + "☆".repeat(3 - stars)]

func _on_fail(reason: String) -> void:
    state = "result"
    hud.visible = false
    result.visible = true
    result_title.text = "TRAFFIC COLLAPSED"
    result_sub.text = reason + " · RETRY WITH CLEANER SIGNAL TIMING"

func _draw() -> void:
    if state != "playing":
        return

    # Make the four actual queue leaders obvious and tappable.
    for entry in ["north", "south", "west", "east"]:
        var v: TWVehicle = traffic.head(entry)
        if is_instance_valid(v):
            draw_arc(v.global_position, 58.0 if not v.emergency else 72.0, 0.0, TAU, 42, Color(0.20, 0.95, 1.0, 0.78), 5.0)

    # Preview all three possible directions once a leader is selected.
    if is_instance_valid(selected):
        var route_colors: Dictionary = {
            "left": Color(0.35, 0.82, 1.0, 0.48),
            "straight": Color(0.35, 1.0, 0.55, 0.62),
            "right": Color(1.0, 0.78, 0.24, 0.48)
        }
        for turn in ["left", "straight", "right"]:
            var pts: PackedVector2Array = road.route_for(selected.entry, turn, selected.emergency)
            draw_polyline(pts, route_colors[turn], 12.0, true)

