extends Node2D

const TEX_WATER = preload("res://assets/environment/water.png")
const TEX_ROAD = preload("res://assets/environment/road.png")
const TEX_PAVE = preload("res://assets/environment/pavement.png")
const TEX_FERRY = preload("res://assets/environment/ferry.png")
const TEX_TREE = preload("res://assets/environment/tree.png")
const TEX_BUILDINGS = [
    preload("res://assets/environment/building_1.png"),
    preload("res://assets/environment/building_2.png"),
    preload("res://assets/environment/building_3.png"),
    preload("res://assets/environment/building_4.png")
]

var road := TWRoadNetwork.new()
var traffic := TWTrafficManager.new()
var selected: TWVehicle = null
var drag_start := Vector2.ZERO
var drag_now := Vector2.ZERO
var dragging := false
var state := "menu"
var banner_time := 0.0
var banner_text := ""

@onready var hud := $HUD
@onready var menu := $Menu
@onready var result := $Result
@onready var score_label := $HUD/Top/Score
@onready var clear_label := $HUD/Top/Cleared
@onready var jam_label := $HUD/Top/Jam
@onready var combo_label := $HUD/Top/Combo
@onready var mission := $HUD/Mission
@onready var signal_btn := $HUD/SignalButton
@onready var result_title := $Result/Card/Title
@onready var result_sub := $Result/Card/Sub

func _ready() -> void:
    add_child(road)
    add_child(traffic)
    traffic.setup(self, road)
    traffic.score_changed.connect(_on_score)
    traffic.ambulance_changed.connect(_on_ambulance)
    traffic.level_complete.connect(_on_complete)
    traffic.level_failed.connect(_on_fail)
    traffic.wave_changed.connect(_on_wave)
    $Menu/Card/Play.pressed.connect(start_game)
    $Result/Card/Again.pressed.connect(start_game)
    signal_btn.pressed.connect(toggle_signal)
    queue_redraw()

func start_game() -> void:
    state="playing"
    menu.visible=false
    result.visible=false
    hud.visible=true
    traffic.start()
    signal_btn.text="N/S  GREEN"
    banner("MORNING FLOW", 2.0)

func toggle_signal() -> void:
    if state!="playing": return
    traffic.toggle_signal()
    signal_btn.text="N/S  GREEN" if traffic.signal_ns else "E/W  GREEN"
    banner("SIGNAL SWITCHED", .65)

func _unhandled_input(event: InputEvent) -> void:
    if state!="playing": return
    var pos := Vector2.ZERO
    if event is InputEventScreenTouch:
        pos=event.position
        if event.pressed: begin_drag(pos)
        else: end_drag(pos)
    elif event is InputEventScreenDrag:
        drag_now=event.position; queue_redraw()
    elif event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT:
        pos=event.position
        if event.pressed: begin_drag(pos)
        else: end_drag(pos)
    elif event is InputEventMouseMotion and dragging:
        drag_now=event.position;queue_redraw()

func begin_drag(pos: Vector2) -> void:
    selected=null
    var best:=99999.0
    for v in traffic.vehicles:
        if is_instance_valid(v) and not v.moving:
            var d:=v.global_position.distance_to(pos)
            if d<48 and d<best: selected=v;best=d
    if selected:
        selected.selected=true;selected.queue_redraw();dragging=true;drag_start=selected.global_position;drag_now=pos;queue_redraw()

func end_drag(pos: Vector2) -> void:
    if not dragging or not selected:
        dragging=false;selected=null;return
    var delta:=pos-drag_start
    var turn:="straight"
    if abs(delta.x)>abs(delta.y):
        if selected.entry in ["north","south"]:
            turn="left" if ((delta.x>0) == (selected.entry=="north")) else "right"
        else: turn="straight"
    else:
        if selected.entry in ["west","east"]:
            turn="left" if ((delta.y<0) == (selected.entry=="west")) else "right"
        else: turn="straight"
    var r: Dictionary = traffic.dispatch(selected, turn)
    banner(r.msg, .95)
    selected.selected=false;selected.queue_redraw();selected=null;dragging=false;queue_redraw()

func _process(delta: float) -> void:
    if banner_time>0:
        banner_time-=delta
        if banner_time<=0 and state=="playing": mission.text="Drag the queue leader toward a route · Manage the signal"
    queue_redraw()

func banner(text: String, duration: float) -> void:
    banner_text=text;banner_time=duration;mission.text=text

func _on_score(score:int, cleared:int, jam:float, combo:int) -> void:
    score_label.text="SCORE  %06d"%score
    clear_label.text="CLEARED  %02d/18"%cleared
    jam_label.text="GRIDLOCK  %02d%%"%int(jam)
    combo_label.text="COMBO  x%d"%combo

func _on_ambulance(seconds: float) -> void:
    if seconds>=0: mission.text="🚑 EMERGENCY · %.1fs · clear WEST queue"%seconds

func _on_wave(name:String) -> void: banner(name,2.0)

func _on_complete(score:int, stars:int) -> void:
    state="result";hud.visible=false;result.visible=true
    result_title.text="KARAKÖY CLEARED"
    result_sub.text="Score %d   ·   %s"%[score,"★".repeat(stars)+"☆".repeat(3-stars)]

func _on_fail(reason:String) -> void:
    state="result";hud.visible=false;result.visible=true
    result_title.text="TRAFFIC COLLAPSED"
    result_sub.text=reason+" · retry with cleaner signal timing"

func _draw() -> void:
    draw_world()
    if dragging and selected:
        draw_polyline(PackedVector2Array([drag_start,drag_now]),Color("#ffe36d"),10,true)
        draw_circle(drag_now,18,Color("#ffe36d"),false,5)

func draw_world() -> void:
    # Sky / Bosphorus / city layers
    draw_rect(Rect2(0,0,1080,1920),Color("#80cbe5"),true)
    draw_rect(Rect2(0,290,1080,350),Color("#49a9c9"),true)
    for y in range(320,620,34): draw_line(Vector2(0,y),Vector2(1080,y),Color(1,1,1,.15),3)
    # distant skyline
    draw_rect(Rect2(0,550,1080,180),Color("#d8b878"),true)
    for x in range(0,1080,90):
        var h:=80+(x%170)
        draw_rect(Rect2(x,570-h,70,h),Color("#cfaa6e"),true)
    # Galata cue
    draw_rect(Rect2(120,365,62,205),Color("#b6935d"),true)
    draw_colored_polygon(PackedVector2Array([Vector2(105,365),Vector2(151,290),Vector2(197,365)]),Color("#8c5b49"))
    # ferry asset
    var fx:=fmod(Time.get_ticks_msec()/15.0,1250.0)-190
    draw_texture_rect(TEX_FERRY, Rect2(fx,405,250,125), false)
    # ground and blocks
    draw_rect(Rect2(0,700,1080,1220),Color("#d9c99f"),true)
    draw_texture_rect(TEX_BUILDINGS[0],Rect2(35,720,315,315),false)
    draw_texture_rect(TEX_BUILDINGS[1],Rect2(725,715,325,325),false)
    draw_texture_rect(TEX_BUILDINGS[2],Rect2(35,1280,320,320),false)
    draw_texture_rect(TEX_BUILDINGS[3],Rect2(720,1305,330,330),false)
    draw_texture_rect(TEX_TREE,Rect2(360,780,92,122),false)
    draw_texture_rect(TEX_TREE,Rect2(650,1390,92,122),false)
    # road cross
    var c:=TWRoadNetwork.CENTER
    draw_rect(Rect2(c.x-178,640,356,1280),Color("#3d4850"),true)
    draw_rect(Rect2(0,c.y-178,1080,356),Color("#3d4850"),true)
    # curbs
    draw_line(Vector2(c.x-178,640),Vector2(c.x-178,1920),Color("#f2ead7"),9)
    draw_line(Vector2(c.x+178,640),Vector2(c.x+178,1920),Color("#f2ead7"),9)
    draw_line(Vector2(0,c.y-178),Vector2(1080,c.y-178),Color("#f2ead7"),9)
    draw_line(Vector2(0,c.y+178),Vector2(1080,c.y+178),Color("#f2ead7"),9)
    # lane markings
    for y in range(650,1900,92): draw_line(Vector2(c.x,y),Vector2(c.x,y+42),Color("#f5e5a5"),5)
    for x in range(0,1080,92): draw_line(Vector2(x,c.y),Vector2(x+42,c.y),Color("#f5e5a5"),5)
    # crosswalks
    for i in range(7):
        draw_rect(Rect2(c.x-150+i*46,c.y-228,28,72),Color(1,1,1,.78),true)
        draw_rect(Rect2(c.x-150+i*46,c.y+156,28,72),Color(1,1,1,.78),true)
        draw_rect(Rect2(c.x-228,c.y-150+i*46,72,28),Color(1,1,1,.78),true)
        draw_rect(Rect2(c.x+156,c.y-150+i*46,72,28),Color(1,1,1,.78),true)
    # hospital
    draw_rect(Rect2(820,1190,190,155),Color("#f4f7f8"),true)
    draw_rect(Rect2(900,1215,28,90),Color("#df5159"),true);draw_rect(Rect2(870,1245,88,28),Color("#df5159"),true)
    draw_string(ThemeDB.fallback_font,Vector2(855,1180),"HOSPITAL",HORIZONTAL_ALIGNMENT_LEFT,-1,26,Color("#17394f"))
    # signals
    draw_signal(Vector2(c.x-225,c.y-215), traffic.signal_ns)
    draw_signal(Vector2(c.x+225,c.y+215), traffic.signal_ns)
    draw_signal(Vector2(c.x+215,c.y-225), not traffic.signal_ns)
    draw_signal(Vector2(c.x-215,c.y+225), not traffic.signal_ns)

func draw_building(pos:Vector2,size:Vector2,wall:Color,roof:Color)->void:
    draw_rect(Rect2(pos+Vector2(10,14),size),Color(0,0,0,.16),true)
    draw_rect(Rect2(pos,size),wall,true)
    draw_colored_polygon(PackedVector2Array([pos+Vector2(-12,28),pos+Vector2(size.x/2,-55),pos+Vector2(size.x+12,28)]),roof)
    for y in range(int(pos.y+45),int(pos.y+size.y-20),55):
        for x in range(int(pos.x+30),int(pos.x+size.x-20),62): draw_rect(Rect2(x,y,28,34),Color("#bde3ec"),true)

func draw_signal(pos:Vector2,green:bool)->void:
    draw_rect(Rect2(pos-Vector2(15,35),Vector2(30,70)),Color("#18242c"),true)
    draw_circle(pos+Vector2(0,-17),8,Color("#28383f") if green else Color("#ff515d"))
    draw_circle(pos+Vector2(0,17),8,Color("#4fe56a") if green else Color("#28383f"))
