extends Node2D

const ROAD_SCRIPT = preload("res://scripts/world/road_network.gd")
const TRAFFIC_SCRIPT = preload("res://scripts/traffic/traffic_manager.gd")

var road = ROAD_SCRIPT.new()
var traffic = TRAFFIC_SCRIPT.new()
var selected = null
var drag_start := Vector2.ZERO
var drag_now := Vector2.ZERO
var dragging := false
var state := "menu"
var banner_time := 0.0
var banner_text := ""
var roadworks_cd := 0.0
var hint_cd := 0.0
var flash_time := 0.0
var pulse_time := 0.0
var last_ambulance_seconds := -1.0

@onready var hud := $HUD
@onready var menu := $Menu
@onready var result := $Result
@onready var score_label := $HUD/Top/Score
@onready var clear_label := $HUD/Top/Cleared
@onready var jam_label := $HUD/Top/Jam
@onready var combo_label := $HUD/Top/Combo
@onready var mission := $HUD/MissionCard/Body
@onready var mission_time := $HUD/MissionCard/Timer
@onready var signal_btn := $HUD/SignalButton
@onready var roadworks_btn := $HUD/RoadworksButton
@onready var hint_btn := $HUD/HintButton
@onready var result_title := $Result/Card/Title
@onready var result_sub := $Result/Card/Sub

func _ready() -> void:
    add_child(road)
    add_child(traffic)
    traffic.setup(self, road)
    traffic.score_changed.connect(_on_score)
    traffic.ambulance_changed.connect(_on_ambulance)
    traffic.level_complete.connect(_on_complete)
    traffic.level_failed.connect(_on_fail)
    traffic.wave_changed.connect(_on_wave)
    $Menu/Card/Play.pressed.connect(start_game)
    $Result/Card/Again.pressed.connect(start_game)
    signal_btn.pressed.connect(toggle_signal)
    roadworks_btn.pressed.connect(use_roadworks)
    hint_btn.pressed.connect(use_hint)
    queue_redraw()

func start_game() -> void:
    state="playing"
    menu.visible=false
    result.visible=false
    hud.visible=true
    traffic.start()
    signal_btn.text="🚦  N/S GREEN"
    roadworks_cd=0;hint_cd=0;flash_time=0
    banner("MORNING FLOW", 2.0)

func toggle_signal() -> void:
    if state!="playing": return
    if not traffic.toggle_signal():
        banner("SIGNAL COOLDOWN", .55)
        return
    signal_btn.text="🚦  N/S GREEN" if traffic.signal_ns else "🚦  E/W GREEN"
    flash_time=.18
    banner("SIGNAL SWITCHED", .7)

func use_roadworks() -> void:
    if state!="playing" or roadworks_cd>0: return
    roadworks_cd=22.0
    traffic.activate_roadworks()
    banner("🚧 ROADWORKS · inflow paused 8s",1.5)

func use_hint() -> void:
    if state!="playing" or hint_cd>0: return
    hint_cd=12.0
    var e:=traffic.suggested_entry()
    banner("💡 CLEAR %s QUEUE NEXT"%e.to_upper(),1.7)

func _unhandled_input(event: InputEvent) -> void:
    if state!="playing": return
    var pos := Vector2.ZERO
    if event is InputEventScreenTouch:
        pos=event.position
        if event.pressed: begin_drag(pos)
        else: end_drag(pos)
    elif event is InputEventScreenDrag:
        drag_now=event.position; queue_redraw()
    elif event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT:
        pos=event.position
        if event.pressed: begin_drag(pos)
        else: end_drag(pos)
    elif event is InputEventMouseMotion and dragging:
        drag_now=event.position;queue_redraw()

func begin_drag(pos: Vector2) -> void:
    selected=null
    var best:=99999.0
    for v in traffic.vehicles:
        if is_instance_valid(v) and not v.moving:
            var d:=v.global_position.distance_to(pos)
            if d<72 and d<best: selected=v;best=d
    if selected:
        selected.selected=true;selected.queue_redraw();dragging=true;drag_start=selected.global_position;drag_now=pos;queue_redraw()

func inferred_turn(pos:Vector2)->String:
    if not selected: return "straight"
    var delta:=pos-drag_start
    if delta.length()<35: return selected.turn
    if abs(delta.x)>abs(delta.y):
        if selected.entry in ["north","south"]:
            return "left" if ((delta.x>0) == (selected.entry=="north")) else "right"
        return "straight"
    else:
        if selected.entry in ["west","east"]:
            return "left" if ((delta.y<0) == (selected.entry=="west")) else "right"
        return "straight"

func end_drag(pos: Vector2) -> void:
    if not dragging or not selected:
        dragging=false;selected=null;return
    var turn:=inferred_turn(pos)
    var r:=traffic.dispatch(selected,turn)
    banner(r.msg, .95)
    if bool(r.get("ok", false)): flash_time=.12
    selected.selected=false;selected.queue_redraw();selected=null;dragging=false;queue_redraw()

func _process(delta: float) -> void:
    pulse_time += delta
    roadworks_cd=max(0.0,roadworks_cd-delta)
    hint_cd=max(0.0,hint_cd-delta)
    flash_time=max(0.0,flash_time-delta)
    roadworks_btn.text="🚧  ROADWORKS  %ds"%int(ceil(roadworks_cd)) if roadworks_cd>0 else "🚧  ROADWORKS"
    hint_btn.text="💡  %ds"%int(ceil(hint_cd)) if hint_cd>0 else "💡  HINT"
    if banner_time>0:
        banner_time-=delta
        if banner_time<=0 and state=="playing" and last_ambulance_seconds<0:
            mission.text="Drag the queue leader toward its route. Keep traffic moving."
    queue_redraw()

func banner(text: String, duration: float) -> void:
    banner_text=text;banner_time=duration;mission.text=text

func _on_score(score:int, cleared:int, jam:float, combo:int) -> void:
    score_label.text="★ %d"%score
    clear_label.text="CLEARED %02d/24"%cleared
    jam_label.text="GRIDLOCK %02d%%"%int(jam)
    combo_label.text="COMBO x%d"%combo
    jam_label.modulate=Color("#ff5a60") if jam>65 else Color("#ffc84a")

func _on_ambulance(seconds: float) -> void:
    last_ambulance_seconds=seconds
    if seconds>=0:
        mission.text="SAVE THE AMBULANCE · Clear the WEST approach"
        mission_time.text="⏱ %02d:%02d"%[int(seconds / 60.0),int(seconds)%60]
        mission_time.visible=true
    else:
        mission_time.visible=false

func _on_wave(name:String) -> void: banner(name,2.0)

func _on_complete(score:int, stars:int) -> void:
    state="result";hud.visible=false;result.visible=true
    result_title.text="PATIENT SAVED · KARAKÖY CLEARED"
    result_sub.text="Score %d   ·   %s\nTraffic stayed under control."%[score,"★".repeat(stars)+"☆".repeat(3-stars)]

func _on_fail(reason:String) -> void:
    state="result";hud.visible=false;result.visible=true
    result_title.text="CITY LOCKED UP"
    result_sub.text=reason+"\nRetry with cleaner signal timing and roadworks."

func _draw() -> void:
    # gameplay readability overlays
    draw_rect(Rect2(0,0,1080,200),Color(0.015,0.025,0.04,.22),true)
    draw_rect(Rect2(0,1640,1080,280),Color(0.01,0.02,0.035,.12),true)
    # live signal glow near junction
    var c:=TWRoadNetwork.CENTER
    var glow:=0.12+0.08*(sin(pulse_time*3.0)*.5+.5)
    var active_color:=Color(0.18,1.0,0.42,glow)
    if traffic.signal_ns:
        draw_line(Vector2(c.x-70,c.y-360),Vector2(c.x-70,c.y-205),active_color,18)
        draw_line(Vector2(c.x+70,c.y+205),Vector2(c.x+70,c.y+360),active_color,18)
    else:
        draw_line(Vector2(c.x-360,c.y+70),Vector2(c.x-205,c.y+70),active_color,18)
        draw_line(Vector2(c.x+205,c.y-70),Vector2(c.x+360,c.y-70),active_color,18)
    # queue-head affordances
    for e in ["north","south","west","east"]:
        var v:=traffic.head(e)
        if v and is_instance_valid(v):
            var ring_col:=Color("#59e6ff") if road.direction_green(e,traffic.signal_ns) else Color("#ff5b62")
            draw_arc(v.global_position,46+4*sin(pulse_time*4),0,TAU,36,Color(ring_col,.75),4)
    if dragging and selected:
        var turn:=inferred_turn(drag_now)
        var route_preview:=road.route_for(selected.entry,turn,selected.emergency)
        if route_preview.size()>1:
            draw_polyline(route_preview,Color(0.1,0.82,1.0,.35),20,true)
            draw_polyline(route_preview,Color("#32d9ff"),7,true)
        draw_polyline(PackedVector2Array([drag_start,drag_now]),Color("#ffe36d"),8,true)
        draw_circle(drag_now,16,Color("#ffe36d"),false,5)
    if flash_time>0:
        draw_rect(Rect2(0,0,1080,1920),Color(1,1,1,flash_time*.35),true)
