extends Node2D

const BG = preload("res://assets/environment/karakoy_final_clean_v2.jpg")
const TEX_CAR = preload("res://assets/vehicles/car_blue.png")
const TEX_TAXI = preload("res://assets/vehicles/taxi.png")
const TEX_BUS = preload("res://assets/vehicles/bus.png")
const TEX_MOTO = preload("res://assets/vehicles/motorcycle.png")
const TEX_AMB = preload("res://assets/vehicles/ambulance.png")

const CENTER := Vector2(540, 1080)
const HEAD_POS := {
    "north": Vector2(470, 905),
    "south": Vector2(610, 1255),
    "west": Vector2(300, 1135),
    "east": Vector2(780, 1025)
}
const QUEUE_AXIS := {
    "north": Vector2(0, -1),
    "south": Vector2(0, 1),
    "west": Vector2(-1, 0),
    "east": Vector2(1, 0)
}

var state := "menu"
var vehicles: Array = []
var queues := {"north": [], "south": [], "west": [], "east": []}
var selected: Dictionary = {}
var signal_ns := true
var elapsed := 0.0
var spawn_clock := 0.0
var spawn_pause := 0.0
var roadworks_cd := 0.0
var hint_cd := 0.0
var siren_cd := 0.0
var spawned := 0
var cleared := 0
var score := 0
var combo := 1
var combo_timer := 0.0
var jam := 0.0
var target := 12
var next_id := 1
var ambulance_spawned := false

var ui := {}

func _ready() -> void:
    $Background.texture = BG
    _build_ui()
    _set_web_state("menu")
    queue_redraw()
    if OS.has_feature("web"):
        var query := String(JavaScriptBridge.eval("window.location.search"))
        if "qa=1" in query:
            call_deferred("_run_web_qa")

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    layer.name = "UI"
    add_child(layer)

    var top := ColorRect.new()
    top.position = Vector2(22, 28)
    top.size = Vector2(1036, 115)
    top.color = Color(0.02, 0.04, 0.07, 0.94)
    layer.add_child(top)

    var title := _label("TRAFFIC WHISPERER", 34, Color(1,1,1), Vector2(48, 48), Vector2(430, 50))
    layer.add_child(title)
    var stats := _label("SCORE 00000    CLEARED 00/12    JAM 00%    COMBO x1", 22, Color(0.75,0.92,1), Vector2(48, 94), Vector2(720, 34))
    layer.add_child(stats)
    ui["stats"] = stats

    var mission := ColorRect.new()
    mission.position = Vector2(26, 165)
    mission.size = Vector2(390, 165)
    mission.color = Color(0.02, 0.04, 0.07, 0.9)
    layer.add_child(mission)
    var m1 := _label("MISSION", 22, Color(1.0,0.78,0.18), Vector2(50,185), Vector2(300,30))
    layer.add_child(m1)
    var m2 := _label("Save the ambulance", 30, Color.WHITE, Vector2(50,220), Vector2(340,44))
    layer.add_child(m2)
    var timer := _label("Ambulance arrives in 8s", 20, Color(0.75,0.92,1), Vector2(50,275), Vector2(340,30))
    layer.add_child(timer)
    ui["mission"] = timer

    var signal := _button("CHANGE LIGHT", Vector2(30, 1630), Vector2(220, 115), Color(0.08,0.16,0.22,0.95))
    signal.pressed.connect(_toggle_signal)
    layer.add_child(signal)
    ui["signal"] = signal

    var roadworks := _button("ROADWORKS", Vector2(270,1630), Vector2(220,115), Color(0.08,0.16,0.22,0.95))
    roadworks.pressed.connect(_roadworks)
    layer.add_child(roadworks)
    ui["roadworks"] = roadworks

    var hint := _button("HINT", Vector2(590,1630), Vector2(200,115), Color(0.08,0.16,0.22,0.95))
    hint.pressed.connect(_hint)
    layer.add_child(hint)
    ui["hint"] = hint

    var siren := _button("SIREN", Vector2(810,1630), Vector2(240,115), Color(0.35,0.05,0.06,0.96))
    siren.pressed.connect(_siren)
    layer.add_child(siren)
    ui["siren"] = siren

    var panel := ColorRect.new()
    panel.position = Vector2(135, 1460)
    panel.size = Vector2(810, 135)
    panel.color = Color(0.02,0.04,0.07,0.94)
    panel.visible = false
    layer.add_child(panel)
    ui["route_panel"] = panel

    var action := _label("SELECT A FRONT VEHICLE", 22, Color.WHITE, Vector2(175,1472), Vector2(730,30))
    action.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    action.visible = false
    layer.add_child(action)
    ui["action"] = action

    var left := _button("LEFT", Vector2(165,1510), Vector2(220,70), Color(0.12,0.22,0.28,1))
    var straight := _button("STRAIGHT", Vector2(430,1510), Vector2(220,70), Color(0.07,0.36,0.18,1))
    var right := _button("RIGHT", Vector2(695,1510), Vector2(220,70), Color(0.12,0.22,0.28,1))
    left.visible = false; straight.visible = false; right.visible = false
    left.pressed.connect(func(): _dispatch("left"))
    straight.pressed.connect(func(): _dispatch("straight"))
    right.pressed.connect(func(): _dispatch("right"))
    layer.add_child(left); layer.add_child(straight); layer.add_child(right)
    ui["left"] = left; ui["straight"] = straight; ui["right"] = right

    var status := _label("Tap the glowing front car, then choose its route.", 22, Color.WHITE, Vector2(55,1780), Vector2(970,45))
    status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    layer.add_child(status)
    ui["status"] = status

    var play_shade := ColorRect.new()
    play_shade.position = Vector2.ZERO
    play_shade.size = Vector2(1080,1920)
    play_shade.color = Color(0.01,0.02,0.04,0.62)
    layer.add_child(play_shade)
    ui["shade"] = play_shade

    var play_card := ColorRect.new()
    play_card.position = Vector2(125,610)
    play_card.size = Vector2(830,560)
    play_card.color = Color(0.94,0.96,0.97,0.98)
    layer.add_child(play_card)
    ui["card"] = play_card

    var t := _label("TRAFFIC WHISPERER", 52, Color(0.04,0.12,0.18), Vector2(185,680), Vector2(710,70))
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    layer.add_child(t); ui["menu_title"] = t
    var s := _label("Karakoy Rescue", 28, Color(0.16,0.34,0.42), Vector2(260,770), Vector2(560,45))
    s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    layer.add_child(s); ui["menu_sub"] = s
    var how := _label("Control the real traffic.\nClear a route for the ambulance.\nNo cars are baked into the background.", 24, Color(0.18,0.26,0.31), Vector2(205,850), Vector2(670,135))
    how.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    layer.add_child(how); ui["menu_how"] = how
    var play := _button("PLAY", Vector2(260,1025), Vector2(560,95), Color(0.05,0.48,0.22,1))
    play.pressed.connect(start_game)
    layer.add_child(play); ui["play"] = play

func _label(text: String, font_size: int, color: Color, pos: Vector2, size: Vector2) -> Label:
    var l := Label.new()
    l.text = text
    l.position = pos
    l.size = size
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_shadow_color", Color(0,0,0,0.55))
    l.add_theme_constant_override("shadow_offset_x", 2)
    l.add_theme_constant_override("shadow_offset_y", 2)
    return l

func _button(text: String, pos: Vector2, size: Vector2, color: Color) -> Button:
    var b := Button.new()
    b.text = text
    b.position = pos
    b.size = size
    b.add_theme_font_size_override("font_size", 25)
    var box := StyleBoxFlat.new()
    box.bg_color = color
    box.corner_radius_top_left = 18
    box.corner_radius_top_right = 18
    box.corner_radius_bottom_left = 18
    box.corner_radius_bottom_right = 18
    box.border_width_left = 2; box.border_width_right = 2; box.border_width_top = 2; box.border_width_bottom = 2
    box.border_color = Color(0.42,0.66,0.78,0.65)
    b.add_theme_stylebox_override("normal", box)
    return b

func start_game() -> void:
    state = "playing"
    for k in ["shade","card","menu_title","menu_sub","menu_how","play"]:
        ui[k].visible = false
    _reset_game()
    _set_web_state("playing")
    _status("Tap a glowing queue leader.")

func _reset_game() -> void:
    for v in vehicles:
        if is_instance_valid(v["node"]): v["node"].queue_free()
    vehicles.clear()
    queues = {"north": [], "south": [], "west": [], "east": []}
    selected = {}
    elapsed = 0.0; spawn_clock = 0.0; spawn_pause = 0.0; roadworks_cd = 0.0; hint_cd = 0.0; siren_cd = 0.0
    spawned = 0; cleared = 0; score = 0; combo = 1; combo_timer = 0.0; jam = 0.0; next_id = 1; ambulance_spawned = false
    signal_ns = true
    _hide_routes()
    for entry in ["north","south","west","east"]:
        _spawn(entry, "car" if entry != "west" else "taxi")
    _spawn("north", "bus")
    _update_ui()
    queue_redraw()

func _process(delta: float) -> void:
    if state != "playing": return
    elapsed += delta
    spawn_clock += delta
    spawn_pause = maxf(0.0, spawn_pause - delta)
    roadworks_cd = maxf(0.0, roadworks_cd - delta)
    hint_cd = maxf(0.0, hint_cd - delta)
    siren_cd = maxf(0.0, siren_cd - delta)
    combo_timer = maxf(0.0, combo_timer - delta)
    if combo_timer <= 0.0: combo = 1

    if not ambulance_spawned and elapsed >= 6.0:
        ambulance_spawned = true
        _spawn("west", "ambulance")
        _status("Ambulance active. Clear the west queue.")

    if spawn_pause <= 0.0 and spawn_clock >= 3.0 and spawned < target:
        spawn_clock = 0.0
        _spawn(_shortest_queue(), _next_type())

    _move_vehicles(delta)
    _reflow()
    var waiting := 0
    for k in queues: waiting += queues[k].size()
    jam = clampf(jam + (maxi(0, waiting - 6) * 1.9 - 5.5) * delta, 0.0, 100.0)
    if jam >= 100.0:
        _finish(false, "GRIDLOCK")
    _update_ui()
    queue_redraw()

func _next_type() -> String:
    var types := ["car","taxi","car","motorcycle","bus"]
    return types[spawned % types.size()]

func _spawn(entry: String, kind: String) -> void:
    var sprite := Sprite2D.new()
    sprite.texture = _texture_for(kind)
    sprite.scale = Vector2(0.82,0.82) if kind != "bus" else Vector2(0.92,0.92)
    if kind == "ambulance": sprite.scale = Vector2(1.0,1.0)
    add_child(sprite)
    var data := {
        "node": sprite, "entry": entry, "kind": kind, "moving": false,
        "route": PackedVector2Array(), "route_i": 0, "speed": 220.0 if kind != "bus" else 175.0,
        "emergency": kind == "ambulance", "timer": 36.0, "id": next_id
    }
    next_id += 1
    vehicles.append(data)
    queues[entry].append(data)
    if kind != "ambulance": spawned += 1
    _reflow()

func _texture_for(kind: String) -> Texture2D:
    match kind:
        "taxi": return TEX_TAXI
        "bus": return TEX_BUS
        "motorcycle": return TEX_MOTO
        "ambulance": return TEX_AMB
        _: return TEX_CAR

func _reflow() -> void:
    for entry in queues:
        var arr: Array = queues[entry]
        for i in range(arr.size()):
            var v: Dictionary = arr[i]
            if not is_instance_valid(v["node"]): continue
            var p: Vector2 = HEAD_POS[entry] + QUEUE_AXIS[entry] * (i * 105.0)
            v["node"].position = v["node"].position.lerp(p, 0.32)
            v["node"].rotation = _rotation_for(entry)

func _rotation_for(entry: String) -> float:
    match entry:
        "north": return PI/2.0
        "south": return -PI/2.0
        "west": return 0.0
        _: return PI

func _input(event: InputEvent) -> void:
    if state != "playing": return
    var pressed := false
    var pos := Vector2.ZERO
    if event is InputEventScreenTouch and event.pressed:
        pressed = true; pos = event.position
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        pressed = true; pos = event.position
    if pressed:
        # UI buttons occupy the top and bottom zones. The central road always remains tappable,
        # even when Controls elsewhere in the CanvasLayer consume GUI events.
        if pos.y >= 350.0 and pos.y <= 1440.0:
            _select_at(pos)

func _select_at(pos: Vector2) -> void:
    var best: Dictionary = {}
    var best_d := 99999.0
    for entry in queues:
        if queues[entry].is_empty(): continue
        var v: Dictionary = queues[entry][0]
        if not is_instance_valid(v["node"]): continue
        var d: float = v["node"].global_position.distance_to(pos)
        if d < 125.0 and d < best_d:
            best = v; best_d = d
    if best.is_empty():
        _status("Tap a cyan-ringed front vehicle.")
        return
    selected = best
    _show_routes()
    _status("Selected. Choose LEFT, STRAIGHT or RIGHT.")
    _set_web_state("selected")
    queue_redraw()

func _show_routes() -> void:
    ui["route_panel"].visible = true; ui["action"].visible = true
    ui["left"].visible = true; ui["straight"].visible = true; ui["right"].visible = true
    ui["action"].text = "CHOOSE ROUTE"

func _hide_routes() -> void:
    ui["route_panel"].visible = false; ui["action"].visible = false
    ui["left"].visible = false; ui["straight"].visible = false; ui["right"].visible = false

func _dispatch(turn: String) -> void:
    if selected.is_empty(): return
    var entry: String = selected["entry"]
    if queues[entry].is_empty() or queues[entry][0] != selected:
        _status("Only the front vehicle can move.")
        return
    if not selected["emergency"] and not _green(entry):
        _status("Red light. Change the signal first.")
        return
    queues[entry].pop_front()
    selected["route"] = _route(entry, turn, selected["emergency"])
    selected["route_i"] = 1
    selected["moving"] = true
    selected = {}
    _hide_routes()
    _status("Vehicle released: " + turn.to_upper())
    _set_web_state("moved")
    queue_redraw()

func _route(entry: String, turn: String, emergency: bool) -> PackedVector2Array:
    var start: Vector2 = HEAD_POS[entry]
    if emergency:
        return PackedVector2Array([start, Vector2(430,1080), Vector2(610,970), Vector2(820,760), Vector2(920,680)])
    var finish := Vector2.ZERO
    if turn == "straight":
        match entry:
            "north": finish = Vector2(610,1530)
            "south": finish = Vector2(470,620)
            "west": finish = Vector2(960,1025)
            "east": finish = Vector2(120,1135)
        return PackedVector2Array([start, CENTER, finish])
    if turn == "left":
        match entry:
            "north": finish = Vector2(960,1025)
            "south": finish = Vector2(120,1135)
            "west": finish = Vector2(470,620)
            "east": finish = Vector2(610,1530)
        return PackedVector2Array([start, CENTER + Vector2(55,-55), finish])
    match entry:
        "north": finish = Vector2(120,1135)
        "south": finish = Vector2(960,1025)
        "west": finish = Vector2(610,1530)
        "east": finish = Vector2(470,620)
    return PackedVector2Array([start, CENTER + Vector2(-55,55), finish])

func _move_vehicles(delta: float) -> void:
    var completed: Array = []
    for v in vehicles:
        if v["emergency"] and not v["moving"]:
            v["timer"] -= delta
            if v["timer"] <= 0.0:
                _finish(false, "AMBULANCE MISSED")
                return
        if not v["moving"]: continue
        var route: PackedVector2Array = v["route"]
        var idx: int = v["route_i"]
        if idx >= route.size():
            completed.append(v); continue
        var node: Sprite2D = v["node"]
        var target_pos := route[idx]
        var delta_pos := target_pos - node.position
        var step: float = v["speed"] * delta
        if delta_pos.length() <= step:
            node.position = target_pos
            v["route_i"] = idx + 1
            if v["route_i"] >= route.size(): completed.append(v)
        else:
            node.position += delta_pos.normalized() * step
            node.rotation = delta_pos.angle()
    for v in completed: _clear_vehicle(v)

func _clear_vehicle(v: Dictionary) -> void:
    if not is_instance_valid(v["node"]): return
    var kind: String = v["kind"]
    score += 650 if kind == "ambulance" else 120 * combo
    combo = mini(combo + 1, 5)
    combo_timer = 3.0
    cleared += 1
    v["node"].queue_free()
    vehicles.erase(v)
    if kind == "ambulance": _status("Patient saved. Keep traffic flowing.")
    if cleared >= target: _finish(true, "KARAKOY CLEARED")

func _green(entry: String) -> bool:
    return (entry == "north" or entry == "south") == signal_ns

func _toggle_signal() -> void:
    if state != "playing": return
    signal_ns = not signal_ns
    _status("NORTH/SOUTH GREEN" if signal_ns else "EAST/WEST GREEN")
    _update_ui(); queue_redraw()

func _roadworks() -> void:
    if state != "playing": return
    if roadworks_cd > 0.0:
        _status("Roadworks recharging."); return
    spawn_pause = 7.0; roadworks_cd = 18.0; jam = maxf(0.0, jam - 15.0)
    _status("Roadworks active: new traffic paused for 7s.")

func _hint() -> void:
    if state != "playing": return
    for entry in queues:
        if not queues[entry].is_empty() and (_green(entry) or queues[entry][0]["emergency"]):
            selected = queues[entry][0]; _show_routes(); _status("Hint selected a movable front vehicle."); queue_redraw(); return
    _status("Switch the traffic light.")

func _siren() -> void:
    if state != "playing": return
    if siren_cd > 0.0:
        _status("Siren recharging."); return
    var amb: Dictionary = {}
    for v in vehicles:
        if v["emergency"] and not v["moving"]: amb = v; break
    if amb.is_empty():
        _status("No waiting ambulance."); return
    var q: Array = queues["west"]
    if q.size() > 1:
        var blocker: Dictionary = q[0]
        if blocker != amb:
            queues["west"].pop_front()
            blocker["route"] = PackedVector2Array([blocker["node"].position, Vector2(960,1025)])
            blocker["route_i"] = 1; blocker["moving"] = true
            siren_cd = 15.0; _status("Siren cleared the ambulance lane.")
            return
    _status("Ambulance lane is already clear.")

func _shortest_queue() -> String:
    var best := "north"
    for k in queues:
        if queues[k].size() < queues[best].size(): best = k
    return best

func _update_ui() -> void:
    if OS.has_feature("web"):
        JavaScriptBridge.eval("window.__tw_score = %d; window.__tw_cleared = %d; window.__tw_jam = %.2f;" % [score, cleared, jam])
    ui["stats"].text = "SCORE %05d    CLEARED %02d/%02d    JAM %02d%%    COMBO x%d" % [score, cleared, target, int(jam), combo]
    ui["signal"].text = "N/S GREEN" if signal_ns else "E/W GREEN"
    ui["roadworks"].text = "ROADWORKS" if roadworks_cd <= 0.0 else "ROADWORKS %ds" % int(ceil(roadworks_cd))
    ui["siren"].text = "SIREN" if siren_cd <= 0.0 else "SIREN %ds" % int(ceil(siren_cd))
    if not ambulance_spawned:
        ui["mission"].text = "Ambulance arrives in %ds" % maxi(0, int(ceil(6.0 - elapsed)))
    else:
        var amb: Dictionary = {}
        for v in vehicles:
            if v["emergency"] and not v["moving"]: amb = v; break
        ui["mission"].text = "Ambulance waiting: %ds" % int(ceil(amb["timer"])) if not amb.is_empty() else "Ambulance en route"

func _status(text: String) -> void:
    ui["status"].text = text

func _finish(ok: bool, reason: String) -> void:
    state = "result"
    _hide_routes()
    ui["shade"].visible = true; ui["card"].visible = true; ui["menu_title"].visible = true; ui["menu_sub"].visible = true; ui["menu_how"].visible = true; ui["play"].visible = true
    ui["menu_title"].text = reason
    ui["menu_sub"].text = "Score %d" % score
    ui["menu_how"].text = "Mission complete." if ok else "Try cleaner signal timing."
    ui["play"].text = "PLAY AGAIN"
    _set_web_state("result")

func _draw() -> void:
    if state != "playing": return
    for entry in queues:
        if queues[entry].is_empty(): continue
        var v: Dictionary = queues[entry][0]
        if not is_instance_valid(v["node"]): continue
        var c := Color(0.12,0.95,1.0,0.95)
        if v["emergency"]: c = Color(1.0,0.24,0.28,0.98)
        draw_arc(v["node"].position, 78.0 if not v["emergency"] else 92.0, 0, TAU, 48, c, 7.0)
    if not selected.is_empty() and is_instance_valid(selected["node"]):
        draw_arc(selected["node"].position, 98.0, 0, TAU, 48, Color(1.0,0.86,0.22,1), 8.0)
        for turn in ["left","straight","right"]:
            var pts := _route(selected["entry"], turn, selected["emergency"])
            var color := Color(0.2,0.8,1,0.42)
            if turn == "straight": color = Color(0.25,1,0.5,0.65)
            if turn == "right": color = Color(1,0.72,0.18,0.48)
            draw_polyline(pts, color, 10.0, true)

func _set_web_state(value: String) -> void:
    if OS.has_feature("web"):
        JavaScriptBridge.eval("window.__tw_state = '%s'; window.__tw_score = %d;" % [value, score])

func _run_web_qa() -> void:
    await get_tree().create_timer(0.4).timeout
    start_game()
    await get_tree().create_timer(0.5).timeout
    var north_head: Dictionary = queues["north"][0] if not queues["north"].is_empty() else {}
    if north_head.is_empty():
        JavaScriptBridge.eval("document.title='TW_QA_FAIL_NO_HEAD'")
        return
    _select_at(north_head["node"].global_position)
    await get_tree().create_timer(0.15).timeout
    if selected.is_empty():
        JavaScriptBridge.eval("document.title='TW_QA_FAIL_SELECT'")
        return
    _dispatch("straight")
    await get_tree().create_timer(1.3).timeout
    var moved := false
    for v in vehicles:
        if bool(v["moving"]):
            moved = true
            break
    if moved and state == "playing":
        JavaScriptBridge.eval("document.title='TW_QA_PASS'; window.__tw_qa='pass';")
    else:
        JavaScriptBridge.eval("document.title='TW_QA_FAIL_MOVE'; window.__tw_qa='fail';")
