extends Node

const CENTER := Vector2(540, 1030)
const ROAD_HALF := 178.0
const LANE := 52.0

func spawn_point(entry: String) -> Vector2:
    match entry:
        "north": return Vector2(CENTER.x - LANE, CENTER.y - 480)
        "south": return Vector2(CENTER.x + LANE, CENTER.y + 480)
        "west": return Vector2(CENTER.x - 480, CENTER.y + LANE)
        _: return Vector2(CENTER.x + 480, CENTER.y - LANE)

func exit_point(exit_name: String) -> Vector2:
    match exit_name:
        "north": return Vector2(CENTER.x + LANE, CENTER.y - 500)
        "south": return Vector2(CENTER.x - LANE, CENTER.y + 500)
        "west": return Vector2(CENTER.x - 500, CENTER.y - LANE)
        _: return Vector2(CENTER.x + 500, CENTER.y + LANE)

func exit_for(entry: String, turn: String) -> String:
    var map := {
        "north":{"straight":"south","left":"east","right":"west"},
        "south":{"straight":"north","left":"west","right":"east"},
        "west":{"straight":"east","left":"north","right":"south"},
        "east":{"straight":"west","left":"south","right":"north"}
    }
    return map[entry][turn]

func route_for(entry: String, turn: String, emergency := false) -> PackedVector2Array:
    var start := spawn_point(entry)
    if emergency:
        return PackedVector2Array([start, Vector2(CENTER.x-20,CENTER.y), Vector2(850,1265)])
    var exit_name := exit_for(entry, turn)
    var finish := exit_point(exit_name)
    var p := PackedVector2Array()
    p.append(start)
    match turn:
        "straight":
            p.append(CENTER)
        "left":
            var bend := CENTER
            if entry == "north": bend += Vector2(72, 52)
            elif entry == "south": bend += Vector2(-72, -52)
            elif entry == "west": bend += Vector2(52, -72)
            else: bend += Vector2(-52, 72)
            p.append(bend)
        "right":
            var bend := CENTER
            if entry == "north": bend += Vector2(-82, -50)
            elif entry == "south": bend += Vector2(82, 50)
            elif entry == "west": bend += Vector2(-50, 82)
            else: bend += Vector2(50, -82)
            p.append(bend)
    p.append(finish)
    return p

func queue_axis(entry: String) -> Vector2:
    if entry == "north": return Vector2(0,-1)
    if entry == "south": return Vector2(0,1)
    if entry == "west": return Vector2(-1,0)
    return Vector2(1,0)

func direction_green(entry: String, signal_ns: bool) -> bool:
    return (entry in ["north","south"]) == signal_ns
