extends Node
class_name TWRoadNetwork

const CENTER := Vector2(540, 995)
const LANE := 68.0

func spawn_point(entry: String) -> Vector2:
    match entry:
        "north":
            return Vector2(CENTER.x - LANE, 565)
        "south":
            return Vector2(CENTER.x + LANE, 1450)
        "west":
            return Vector2(120, CENTER.y + LANE)
        _:
            return Vector2(960, CENTER.y - LANE)

func exit_point(exit_name: String) -> Vector2:
    match exit_name:
        "north":
            return Vector2(CENTER.x + LANE, 520)
        "south":
            return Vector2(CENTER.x - LANE, 1700)
        "west":
            return Vector2(80, CENTER.y - LANE)
        _:
            return Vector2(1000, CENTER.y + LANE)

func exit_for(entry: String, turn: String) -> String:
    var map: Dictionary = {
        "north": {"straight": "south", "left": "east", "right": "west"},
        "south": {"straight": "north", "left": "west", "right": "east"},
        "west": {"straight": "east", "left": "north", "right": "south"},
        "east": {"straight": "west", "left": "south", "right": "north"}
    }
    return String(map[entry][turn])

func route_for(entry: String, turn: String, emergency: bool = false) -> PackedVector2Array:
    var start: Vector2 = spawn_point(entry)

    # The photo's baked green route bends from the left side through the intersection
    # and toward the lower-right. Match that for the rescue vehicle.
    if emergency:
        return PackedVector2Array([
            start,
            Vector2(390, 1010),
            Vector2(555, 1110),
            Vector2(720, 1260),
            Vector2(820, 1540)
        ])

    var exit_name: String = exit_for(entry, turn)
    var finish: Vector2 = exit_point(exit_name)
    var points := PackedVector2Array()
    points.append(start)

    match turn:
        "straight":
            points.append(CENTER)
        "left":
            var bend: Vector2 = CENTER
            if entry == "north":
                bend += Vector2(94, 60)
            elif entry == "south":
                bend += Vector2(-94, -60)
            elif entry == "west":
                bend += Vector2(60, -94)
            else:
                bend += Vector2(-60, 94)
            points.append(bend)
        "right":
            var bend: Vector2 = CENTER
            if entry == "north":
                bend += Vector2(-104, -64)
            elif entry == "south":
                bend += Vector2(104, 64)
            elif entry == "west":
                bend += Vector2(-64, 104)
            else:
                bend += Vector2(64, -104)
            points.append(bend)

    points.append(finish)
    return points

func queue_axis(entry: String) -> Vector2:
    if entry == "north":
        return Vector2(0, -1)
    if entry == "south":
        return Vector2(0, 1)
    if entry == "west":
        return Vector2(-1, 0)
    return Vector2(1, 0)

func direction_green(entry: String, signal_ns: bool) -> bool:
    return (entry in ["north", "south"]) == signal_ns
