extends Node

signal score_changed(score, cleared, gridlock, combo)
signal ambulance_changed(seconds_left)
signal level_complete(score, stars)
signal level_failed(reason)
signal wave_changed(name)

var world: Node2D
var road
var vehicles: Array = []
var queues := {"north":[],"south":[],"west":[],"east":[]}
var signal_ns := true
var elapsed := 0.0
var spawn_clock := 0.0
var spawned := 0
var cleared := 0
var score := 0
var combo := 1
var combo_timer := 0.0
var gridlock := 0.0
var target := 24
var active := false
var ambulance_spawned := false
var next_id := 1
var wave_index := 0
var spawn_pause := 0.0
var signal_cooldown := 0.0
var waves := [
    {"name":"MORNING FLOW","until":30.0,"interval":2.45},
    {"name":"FERRY RUSH","until":62.0,"interval":1.95},
    {"name":"PEAK HOUR","until":102.0,"interval":1.55}
]

func setup(world_node: Node2D, road_network) -> void:
    world = world_node
    road = road_network

func start() -> void:
    for v in vehicles:
        if is_instance_valid(v): v.queue_free()
    vehicles.clear()
    for k in queues: queues[k] = []
    elapsed=0;spawn_clock=0;spawned=0;cleared=0;score=0;combo=1;combo_timer=0;gridlock=0;ambulance_spawned=false;next_id=1;wave_index=0;active=true;spawn_pause=0;signal_cooldown=0
    wave_changed.emit(waves[0].name)
    for e in ["north","west","south","east"]:
        spawn_vehicle(e)
        spawn_vehicle(e)
    emit_state()

func _process(delta: float) -> void:
    if not active: return
    elapsed += delta
    spawn_clock += delta
    spawn_pause = max(0.0, spawn_pause-delta)
    signal_cooldown = max(0.0, signal_cooldown-delta)
    combo_timer = max(0.0, combo_timer-delta)
    if combo_timer <= 0: combo = 1
    while wave_index < waves.size()-1 and elapsed > float(waves[wave_index].until):
        wave_index += 1
        wave_changed.emit(waves[wave_index].name)
    if elapsed > 17.0 and not ambulance_spawned:
        ambulance_spawned = true
        spawn_vehicle("west", "ambulance")
    if spawn_pause <= 0 and spawn_clock >= float(waves[wave_index].interval) and spawned < target:
        spawn_clock=0
        spawn_vehicle(shortest_queue())
    reflow_queues(delta)
    update_gridlock(delta)
    if gridlock >= 100.0:
        active=false
        level_failed.emit("GRIDLOCK")

func shortest_queue() -> String:
    var best := "north"
    for k in queues:
        if queues[k].size() < queues[best].size(): best = k
    return best

func spawn_vehicle(entry: String, forced_type := "") -> void:
    if forced_type == "" and spawned >= target: return
    var v = preload("res://scripts/traffic/vehicle.gd").new()
    var types := ["car","taxi","car","motorcycle","bus","taxi"]
    var typ: String = forced_type if forced_type != "" else types[spawned % types.size()]
    var turn := ["straight","right","left"][spawned % 3]
    var colors := [Color("#62c989"),Color("#ffd13e"),Color("#4ba7e8"),Color("#ec6a5e"),Color("#816fd1"),Color("#f2f2f2")]
    v.configure({"entry":entry,"turn":turn,"type":typ,"id":next_id,"speed":195.0 if typ!="bus" else 155.0,"tint":Color.WHITE if typ=="ambulance" else colors[spawned%colors.size()]})
    next_id += 1
    v.global_position = road.spawn_point(entry)
    v.cleared.connect(_on_vehicle_cleared)
    v.expired.connect(_on_vehicle_expired)
    world.add_child(v)
    vehicles.append(v)
    queues[entry].append(v)
    if forced_type == "": spawned += 1
    reflow_queues(0.0)

func head(entry: String):
    cleanup_queue(entry)
    return queues[entry][0] if queues[entry].size()>0 else null

func dispatch(v, turn_override := "") -> Dictionary:
    if not active or not is_instance_valid(v) or v.moving: return {"ok":false,"msg":"Vehicle unavailable"}
    if head(v.entry) != v: return {"ok":false,"msg":"Clear the first vehicle in that queue"}
    if not v.emergency and not road.direction_green(v.entry, signal_ns): return {"ok":false,"msg":"RED LIGHT — change the signal"}
    if intersection_busy() and not v.emergency: return {"ok":false,"msg":"JUNCTION OCCUPIED — wait"}
    if turn_override != "": v.turn = turn_override
    queues[v.entry].erase(v)
    v.set_route(road.route_for(v.entry, v.turn, v.emergency))
    return {"ok":true,"msg":"🚑 AMBULANCE PRIORITY" if v.emergency else v.turn.to_upper()+" ROUTE"}

func intersection_busy() -> bool:
    for v in vehicles:
        if v.moving and v.global_position.distance_to(Vector2(540, 1030)) < 205: return true
    return false

func toggle_signal() -> bool:
    if signal_cooldown > 0.0: return false
    signal_ns = not signal_ns
    signal_cooldown = 0.55
    return true

func activate_roadworks() -> void:
    if not active: return
    spawn_pause = max(spawn_pause, 8.0)
    gridlock = max(0.0, gridlock-10.0)
    emit_state()

func suggested_entry() -> String:
    var best := "north"
    for k in queues:
        if queues[k].size() > queues[best].size(): best = k
    return best

func reflow_queues(_delta: float) -> void:
    for entry in queues:
        cleanup_queue(entry)
        var offset := 0.0
        for v in queues[entry]:
            var gap := 22.0
            var target_pos := road.spawn_point(entry) + road.queue_axis(entry) * offset
            v.global_position = v.global_position.lerp(target_pos, 0.24)
            v.queue_position = target_pos
            offset += v.body_length()+gap

func cleanup_queue(entry: String) -> void:
    queues[entry] = queues[entry].filter(func(v): return is_instance_valid(v) and not v.moving)

func update_gridlock(delta: float) -> void:
    var waiting := 0
    for entry in queues: waiting += queues[entry].size()
    var pressure := max(0, waiting-7)
    gridlock = clamp(gridlock + (pressure*2.25 - 6.6)*delta, 0.0, 100.0)
    emit_state()

func emit_state() -> void:
    score_changed.emit(score, cleared, gridlock, combo)
    var amb = null
    for v in vehicles:
        if is_instance_valid(v) and v.emergency and not v.moving:
            amb=v;break
    ambulance_changed.emit(amb.life_timer if amb else -1.0)

func _on_vehicle_cleared(v) -> void:
    if not is_instance_valid(v): return
    cleared += 1
    combo = min(5, combo+1) if combo_timer>0 else 1
    combo_timer = 3.2
    var base := 120
    if v.vehicle_type=="taxi": base=145
    elif v.vehicle_type=="bus": base=190
    elif v.vehicle_type=="motorcycle": base=130
    elif v.vehicle_type=="ambulance": base=800
    score += base*combo
    vehicles.erase(v)
    v.queue_free()
    emit_state()
    if cleared >= target:
        active=false
        var stars := 3 if gridlock<30 else (2 if gridlock<60 else 1)
        level_complete.emit(score, stars)

func _on_vehicle_expired(_v) -> void:
    active=false
    level_failed.emit("AMBULANCE MISSED")
