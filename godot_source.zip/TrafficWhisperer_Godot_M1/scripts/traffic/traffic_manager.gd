extends Node
class_name TWTrafficManager

signal score_changed(score, cleared, gridlock, combo)
signal ambulance_changed(seconds_left)
signal level_complete(score, stars)
signal level_failed(reason)
signal wave_changed(name)

var world: Node2D
var road: TWRoadNetwork
var vehicles: Array[TWVehicle] = []
var queues: Dictionary = {"north": [], "south": [], "west": [], "east": []}
var signal_ns: bool = true
var elapsed: float = 0.0
var spawn_clock: float = 0.0
var spawned: int = 0
var cleared: int = 0
var score: int = 0
var combo: int = 1
var combo_timer: float = 0.0
var gridlock: float = 0.0
var target: int = 18
var active: bool = false
var ambulance_spawned: bool = false
var next_id: int = 1
var wave_index: int = 0
var spawn_pause: float = 0.0
var roadworks_cooldown: float = 0.0
var signal_cooldown: float = 0.0

var waves: Array[Dictionary] = [
    {"name": "MORNING FLOW", "until": 30.0, "interval": 3.4},
    {"name": "FERRY RUSH", "until": 62.0, "interval": 2.6},
    {"name": "PEAK HOUR", "until": 100.0, "interval": 1.95}
]

func setup(world_node: Node2D, road_network: TWRoadNetwork) -> void:
    world = world_node
    road = road_network

func start() -> void:
    for v in vehicles:
        if is_instance_valid(v):
            v.queue_free()

    vehicles.clear()
    for key in queues:
        queues[key] = []

    elapsed = 0.0
    spawn_clock = 0.0
    spawned = 0
    cleared = 0
    score = 0
    combo = 1
    combo_timer = 0.0
    gridlock = 0.0
    ambulance_spawned = false
    next_id = 1
    wave_index = 0
    spawn_pause = 0.0
    roadworks_cooldown = 0.0
    signal_cooldown = 0.0
    signal_ns = true
    active = true

    wave_changed.emit(String(waves[0]["name"]))

    # Two lanes are immediately playable, while the other directions build pressure.
    for entry in ["north", "west", "south", "east"]:
        spawn_vehicle(entry)

    emit_state()

func _process(delta: float) -> void:
    if not active:
        return

    elapsed += delta
    spawn_clock += delta
    combo_timer = maxf(0.0, combo_timer - delta)
    spawn_pause = maxf(0.0, spawn_pause - delta)
    roadworks_cooldown = maxf(0.0, roadworks_cooldown - delta)
    signal_cooldown = maxf(0.0, signal_cooldown - delta)

    if combo_timer <= 0.0:
        combo = 1

    while wave_index < waves.size() - 1 and elapsed > float(waves[wave_index]["until"]):
        wave_index += 1
        wave_changed.emit(String(waves[wave_index]["name"]))

    # The rescue mission appears early instead of making the player wait 22 seconds.
    if elapsed > 8.0 and not ambulance_spawned:
        ambulance_spawned = true
        spawn_vehicle("west", "ambulance")

    if spawn_pause <= 0.0 and spawn_clock >= float(waves[wave_index]["interval"]) and spawned < target:
        spawn_clock = 0.0
        spawn_vehicle(shortest_queue())

    reflow_queues(delta)
    update_gridlock(delta)

    if gridlock >= 100.0:
        active = false
        level_failed.emit("GRIDLOCK")

func shortest_queue() -> String:
    var best: String = "north"
    for key in queues:
        if queues[key].size() < queues[best].size():
            best = String(key)
    return best

func spawn_vehicle(entry: String, forced_type: String = "") -> void:
    if forced_type == "" and spawned >= target:
        return

    var v := TWVehicle.new()
    var types: Array[String] = ["car", "taxi", "car", "motorcycle", "bus"]
    var typ: String = forced_type if forced_type != "" else types[spawned % types.size()]
    var turns: Array[String] = ["straight", "right", "left"]
    var turn: String = turns[spawned % turns.size()]
    var colors: Array[Color] = [
        Color("#62c989"),
        Color("#ffd13e"),
        Color("#4ba7e8"),
        Color("#ec6a5e"),
        Color("#816fd1")
    ]

    v.configure({
        "entry": entry,
        "turn": turn,
        "type": typ,
        "id": next_id,
        "speed": 205.0 if typ != "bus" else 155.0,
        "tint": Color.WHITE if typ == "ambulance" else colors[spawned % colors.size()]
    })

    next_id += 1
    v.global_position = road.spawn_point(entry)
    v.cleared.connect(_on_vehicle_cleared)
    v.expired.connect(_on_vehicle_expired)
    world.add_child(v)
    vehicles.append(v)
    queues[entry].append(v)

    if forced_type == "":
        spawned += 1

    reflow_queues(0.0)

func head(entry: String) -> TWVehicle:
    cleanup_queue(entry)
    return queues[entry][0] if queues[entry].size() > 0 else null

func dispatch(v: TWVehicle, turn_override: String = "") -> Dictionary:
    if not active or not is_instance_valid(v) or v.moving:
        return {"ok": false, "msg": "VEHICLE UNAVAILABLE"}

    if head(v.entry) != v:
        return {"ok": false, "msg": "CLEAR THE FRONT CAR FIRST"}

    if not v.emergency and not road.direction_green(v.entry, signal_ns):
        return {"ok": false, "msg": "RED LIGHT · TAP CHANGE LIGHT"}

    if intersection_busy() and not v.emergency:
        return {"ok": false, "msg": "WAIT · INTERSECTION OCCUPIED"}

    if turn_override != "":
        v.turn = turn_override

    queues[v.entry].erase(v)
    v.is_head = false
    v.set_route(road.route_for(v.entry, v.turn, v.emergency))

    return {
        "ok": true,
        "msg": "AMBULANCE PRIORITY · GO!" if v.emergency else v.turn.to_upper() + " · RELEASED"
    }

func intersection_busy() -> bool:
    for v in vehicles:
        if is_instance_valid(v) and v.moving and v.global_position.distance_to(TWRoadNetwork.CENTER) < 175.0:
            return true
    return false

func toggle_signal() -> Dictionary:
    if signal_cooldown > 0.0:
        return {"ok": false, "msg": "SIGNAL CHANGING…"}

    signal_ns = not signal_ns
    signal_cooldown = 0.7
    return {
        "ok": true,
        "msg": "N/S GREEN" if signal_ns else "E/W GREEN"
    }

func activate_roadworks() -> Dictionary:
    if roadworks_cooldown > 0.0:
        return {"ok": false, "msg": "ROADWORKS RECHARGE · %ds" % int(ceil(roadworks_cooldown))}

    spawn_pause = 7.0
    roadworks_cooldown = 18.0
    gridlock = maxf(0.0, gridlock - 14.0)
    emit_state()
    return {"ok": true, "msg": "ROADWORKS · NEW TRAFFIC PAUSED 7s"}

func recommended_head() -> TWVehicle:
    var best: TWVehicle = null
    var best_size: int = -1

    for entry in ["north", "south", "west", "east"]:
        if road.direction_green(entry, signal_ns):
            cleanup_queue(entry)
            if queues[entry].size() > best_size and queues[entry].size() > 0:
                best = queues[entry][0]
                best_size = queues[entry].size()

    return best

func reflow_queues(_delta: float) -> void:
    for entry in queues:
        cleanup_queue(String(entry))
        var offset: float = 0.0
        var index: int = 0

        for item in queues[entry]:
            var v: TWVehicle = item
            var gap: float = 34.0
            var target_pos: Vector2 = road.spawn_point(String(entry)) + road.queue_axis(String(entry)) * offset
            v.global_position = v.global_position.lerp(target_pos, 0.28)
            v.queue_position = target_pos
            v.is_head = index == 0
            v.queue_redraw()
            offset += v.body_length() + gap
            index += 1

func cleanup_queue(entry: String) -> void:
    queues[entry] = queues[entry].filter(
        func(v: Variant) -> bool:
            return is_instance_valid(v) and not v.moving
    )

func update_gridlock(delta: float) -> void:
    var waiting: int = 0
    for entry in queues:
        waiting += queues[entry].size()

    var pressure: int = maxi(0, waiting - 6)
    gridlock = clampf(gridlock + (float(pressure) * 2.2 - 7.4) * delta, 0.0, 100.0)
    emit_state()

func emit_state() -> void:
    score_changed.emit(score, cleared, gridlock, combo)

    var amb: TWVehicle = null
    for v in vehicles:
        if is_instance_valid(v) and v.emergency and not v.moving:
            amb = v
            break

    ambulance_changed.emit(amb.life_timer if is_instance_valid(amb) else -1.0)

func _on_vehicle_cleared(v: TWVehicle) -> void:
    if not is_instance_valid(v):
        return

    cleared += 1
    combo = mini(5, combo + 1) if combo_timer > 0.0 else 1
    combo_timer = 3.4

    var base: int = 120
    if v.vehicle_type == "taxi":
        base = 145
    elif v.vehicle_type == "bus":
        base = 190
    elif v.vehicle_type == "motorcycle":
        base = 130
    elif v.vehicle_type == "ambulance":
        base = 700

    score += base * combo
    vehicles.erase(v)
    v.queue_free()
    emit_state()

    if cleared >= target:
        active = false
        var stars: int = 3 if gridlock < 35.0 else (2 if gridlock < 65.0 else 1)
        level_complete.emit(score, stars)

func _on_vehicle_expired(_v: TWVehicle) -> void:
    active = false
    level_failed.emit("AMBULANCE MISSED")
