extends Node2D
class_name TWVehicle

const TEX_TAXI = preload("res://assets/vehicles/taxi.png")
const TEX_CAR = preload("res://assets/vehicles/car_blue.png")
const TEX_BUS = preload("res://assets/vehicles/bus.png")
const TEX_AMB = preload("res://assets/vehicles/ambulance.png")
const TEX_MOTO = preload("res://assets/vehicles/motorcycle.png")

signal cleared(vehicle)
signal expired(vehicle)

var entry: String = "north"
var turn: String = "straight"
var vehicle_type: String = "car"
var speed: float = 160.0
var route: PackedVector2Array = PackedVector2Array()
var route_index: int = 0
var moving: bool = false
var selected: bool = false
var is_head: bool = false
var emergency: bool = false
var life_timer: float = -1.0
var queue_position: Vector2 = Vector2.ZERO
var tint: Color = Color("#56c98a")
var id_number: int = 0

func _ready() -> void:
    set_process(true)
    queue_redraw()

func configure(data: Dictionary) -> void:
    entry = String(data.get("entry", "north"))
    turn = String(data.get("turn", "straight"))
    vehicle_type = String(data.get("type", "car"))
    emergency = vehicle_type == "ambulance"
    id_number = int(data.get("id", 0))
    speed = float(data.get("speed", 160.0))
    life_timer = 34.0 if emergency else -1.0
    tint = data.get("tint", Color("#56c98a"))
    queue_redraw()

func set_route(points: PackedVector2Array) -> void:
    route = points
    route_index = 0
    moving = route.size() > 1
    selected = false
    is_head = false
    queue_redraw()

func _process(delta: float) -> void:
    if emergency and not moving and life_timer > 0.0:
        life_timer -= delta
        if life_timer <= 0.0:
            expired.emit(self)

    if not moving or route.size() < 2:
        return

    var target: Vector2 = route[route_index + 1]
    var to_target: Vector2 = target - global_position
    var distance: float = to_target.length()
    var step: float = speed * delta

    if distance <= step:
        global_position = target
        route_index += 1

        if route_index >= route.size() - 1:
            moving = false
            cleared.emit(self)
            return
    else:
        global_position += to_target.normalized() * step
        rotation = to_target.angle()

func hit_test(point: Vector2) -> bool:
    var radius: float = 92.0 if vehicle_type == "bus" else 78.0
    if emergency:
        radius = 100.0
    return global_position.distance_to(point) <= radius

func body_length() -> float:
    match vehicle_type:
        "bus":
            return 112.0
        "motorcycle":
            return 58.0
        "ambulance":
            return 90.0
        _:
            return 78.0

func _draw() -> void:
    var tex: Texture2D = TEX_CAR
    var size: Vector2 = Vector2(108, 108)

    match vehicle_type:
        "taxi":
            tex = TEX_TAXI
            size = Vector2(112, 112)
        "bus":
            tex = TEX_BUS
            size = Vector2(150, 122)
        "motorcycle":
            tex = TEX_MOTO
            size = Vector2(82, 82)
        "ambulance":
            tex = TEX_AMB
            size = Vector2(132, 118)
        _:
            tex = TEX_CAR

    # Soft shadow makes the live object readable against the photographic scene.
    draw_circle(Vector2(7, 9), minf(size.x, size.y) * 0.31, Color(0, 0, 0, 0.26))
    draw_texture_rect(tex, Rect2(-size / 2.0, size), false, tint if vehicle_type == "car" else Color.WHITE)

    if is_head:
        draw_arc(Vector2.ZERO, maxf(size.x, size.y) * 0.58, 0.0, TAU, 42, Color(0.12, 0.95, 1.0, 0.92), 6.0)

    if selected:
        draw_arc(Vector2.ZERO, maxf(size.x, size.y) * 0.68, 0.0, TAU, 42, Color("#ffe36d"), 8.0)

    if emergency:
        draw_arc(Vector2.ZERO, maxf(size.x, size.y) * 0.76, 0.0, TAU, 42, Color(1.0, 0.18, 0.25, 0.9), 5.0)

        if not moving and life_timer > 0.0:
            draw_string(
                ThemeDB.fallback_font,
                Vector2(-34, -78),
                "%ds" % int(ceil(life_timer)),
                HORIZONTAL_ALIGNMENT_CENTER,
                68,
                24,
                Color.WHITE
            )
