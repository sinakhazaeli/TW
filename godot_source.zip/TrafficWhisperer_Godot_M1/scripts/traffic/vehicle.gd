extends Node2D
class_name TWVehicle

const TEX_TAXI = preload("res://assets/vehicles/taxi.png")
const TEX_CAR = preload("res://assets/vehicles/car_blue.png")
const TEX_BUS = preload("res://assets/vehicles/bus.png")
const TEX_AMB = preload("res://assets/vehicles/ambulance.png")
const TEX_MOTO = preload("res://assets/vehicles/motorcycle.png")

signal cleared(vehicle)
signal expired(vehicle)

var entry := "north"
var turn := "straight"
var vehicle_type := "car"
var speed := 160.0
var route: PackedVector2Array = PackedVector2Array()
var route_index := 0
var moving := false
var selected := false
var emergency := false
var life_timer := -1.0
var queue_position := Vector2.ZERO
var tint := Color("#56c98a")
var id_number := 0

func _ready() -> void:
    set_process(true)
    queue_redraw()

func configure(data: Dictionary) -> void:
    entry = data.get("entry", "north")
    turn = data.get("turn", "straight")
    vehicle_type = data.get("type", "car")
    emergency = vehicle_type == "ambulance"
    id_number = int(data.get("id", 0))
    speed = float(data.get("speed", 160.0))
    life_timer = 30.0 if emergency else -1.0
    tint = data.get("tint", Color("#56c98a"))
    queue_redraw()

func set_route(points: PackedVector2Array) -> void:
    route = points
    route_index = 0
    moving = route.size() > 1
    selected = false
    queue_redraw()

func _process(delta: float) -> void:
    if emergency and not moving and life_timer > 0.0:
        life_timer -= delta
        if life_timer <= 0.0:
            expired.emit(self)
    if not moving or route.size() < 2:
        return
    var target := route[route_index + 1]
    var to_target := target - global_position
    var distance := to_target.length()
    var step := speed * delta
    if distance <= step:
        global_position = target
        route_index += 1
        if route_index >= route.size() - 1:
            moving = false
            cleared.emit(self)
            return
    else:
        global_position += to_target.normalized() * step
        rotation = to_target.angle()

func hit_test(point: Vector2) -> bool:
    return global_position.distance_to(point) <= (42.0 if vehicle_type == "bus" else 34.0)

func body_length() -> float:
    match vehicle_type:
        "bus": return 72.0
        "motorcycle": return 34.0
        "ambulance": return 58.0
        _: return 50.0

func _draw() -> void:
    var tex: Texture2D = TEX_CAR
    var size := Vector2(64,64)
    match vehicle_type:
        "taxi": tex = TEX_TAXI
        "bus": tex = TEX_BUS; size = Vector2(88,72)
        "motorcycle": tex = TEX_MOTO; size = Vector2(48,48)
        "ambulance": tex = TEX_AMB; size = Vector2(76,68)
        _: tex = TEX_CAR
    draw_texture_rect(tex, Rect2(-size/2.0, size), false, tint if vehicle_type == "car" else Color.WHITE)
    if selected:
        draw_arc(Vector2.ZERO, max(size.x,size.y)*0.58, 0, TAU, 40, Color("#ffe36d"), 5.0)
    if emergency and not moving and life_timer > 0:
        draw_string(ThemeDB.fallback_font, Vector2(-18,-42), str(int(ceil(life_timer))), HORIZONTAL_ALIGNMENT_CENTER, 36, 18, Color.WHITE)

func _rounded_box(color: Color, radius: float) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = color
    s.corner_radius_top_left = int(radius)
    s.corner_radius_top_right = int(radius)
    s.corner_radius_bottom_left = int(radius)
    s.corner_radius_bottom_right = int(radius)
    return s
